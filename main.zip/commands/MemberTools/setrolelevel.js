const { SlashCommandBuilder, EmbedBuilder, roleMention, userMention } = require('discord.js');

const fs = require('node:fs');
const path = require('node:path');
const mongoose = require('mongoose');

const Configuration = mongoose.models.Configuration;
const RoleLevel = mongoose.models.RoleLevel;
const Level = mongoose.models.Level;

module.exports = {
    data: new SlashCommandBuilder()
        .setName('levelsetrole')
        .setDescription('Link a level to a role.')
        .addIntegerOption(option =>
            option
                .setName('level')
                .setDescription('The level to set for the role')
                .setRequired(true)
        )
        .addRoleOption(option =>
            option
                .setName('role')
                .setDescription('The role to link the level to')
                .setRequired(true)
        ),
    log: true,
    async execute(interaction) {
        await interaction.deferReply({ephemeral: true})

        const role = interaction.options.getRole('role');
        const level = interaction.options.getInteger('level');

        const config = await Configuration.findOne({ GuildId: interaction.guild.id })

        if (interaction.user.id != interaction.guild.ownerId) {
            const embed = new EmbedBuilder()
                .setTitle('❌ Oops | Permission Denied')
                .setDescription('You are not allowed to use this command!')
                .setColor('Red')
                .setFooter({ text: `Powered by ${interaction.client.user.username}`})
                .setTimestamp();
            await interaction.editReply({ embeds: [embed] })
            return
        }


        if (level < 0) {
            const embed = new EmbedBuilder()
                .setTitle('❌ Oops | Invalid Level')
                .setDescription('Level must be a positive integer.')
                .setColor('Red')
                .setFooter({ text: `Powered by ${interaction.client.user.username}`})
                .setTimestamp();
            return interaction.editReply({ embeds: [embed] });
        }

        const NoRoles = RoleLevel.countDocuments({ GuildId: interaction.guild.id })

        if (NoRoles >= 25) {
            const embed = new EmbedBuilder()
                .setTitle('❌ Oops | Maximum roles reached')
                .setDescription('Please delete a few roles before trying again.')
                .setColor('Red')
                .setFooter({ text: `Powered by ${interaction.client.user.username}`})
                .setTimestamp();
            return interaction.editReply({ embeds: [embed] });
        }

        await RoleLevel.findOneAndUpdate(
            { GuildId: interaction.guild.id, roleId: role.id },
            { $set: { level: level }, $setOnInsert: { GuildId: interaction.guild.id, roleId: role.id } },
            { upsert: true, new: true }
        );

        await interaction.guild.members.fetch();

        const membersWithRole = interaction.guild.members.cache.filter(m =>
            m.roles.cache.has(role.id)
        );
        
        for (const member of membersWithRole.values()) {
            await Level.findOneAndUpdate(
                { GuildId: interaction.guild.id, userId: member.id },
                { $set: { level: level }, $setOnInsert: { GuildId: interaction.guild.id, userId: member.id, Experience: 0 } },
                { upsert: true, new: true }
            );
        }
                
        const Embed = new EmbedBuilder()
            .setTitle('✅ Success! | Level Updated')
            .setDescription(`${roleMention(role.id)}'s level has been set to ${level}!`)
            .addFields({
                name: "Moderator",
                value: userMention(interaction.user.id)
            })
            .setColor('Green')
            .setFooter({ text: `Powered by ${interaction.client.user.username}`})
            .setTimestamp();

        try {
            const LogChannel  = await interaction.client.channels.fetch(config.LogsChannelID);

            await LogChannel.send({ embeds: [Embed] });
        } catch (err) {
            console.error('Failed to send log message:', err);
        }

        await interaction.editReply({ embeds: [Embed] });
    }
}
